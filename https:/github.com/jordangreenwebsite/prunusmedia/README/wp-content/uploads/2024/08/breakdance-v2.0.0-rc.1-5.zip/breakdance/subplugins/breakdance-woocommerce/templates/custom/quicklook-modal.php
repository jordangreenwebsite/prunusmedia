<div class="bde-woo-quicklook">
    <div class="bde-woo-quicklook-modal breakdance-woocommerce">
        <div class="bde-woo-quicklook-modal-body"></div>

        <button class="bde-woo-quicklook-modal-close">×</button>
    </div>

    <?php if (Breakdance\WooCommerce\shouldShowQuicklookArrows()) { ?>
        <button class="bde-woo-quicklook-modal-prev">Prev</button>
        <button class="bde-woo-quicklook-modal-next">Next</button>
    <?php } ?>

    <span class="bde-woo-quicklook-modal-overlay"></span>
</div>
