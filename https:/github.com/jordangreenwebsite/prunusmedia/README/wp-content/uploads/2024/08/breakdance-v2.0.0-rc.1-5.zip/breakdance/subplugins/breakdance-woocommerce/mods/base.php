<?php

namespace Breakdance\WooCommerce;

require_once __DIR__ . "/template-hooks.php";
require_once __DIR__ . "/cart.php";
require_once __DIR__ . "/checkout.php";
require_once __DIR__ . "/add-to-cart.php";
require_once __DIR__ . "/product-tabs.php";
require_once __DIR__ . "/customizer.php";
require_once __DIR__ . "/price.php";
require_once __DIR__ . "/quantity-input.php";
require_once __DIR__ . "/variation-swatches.php";
require_once __DIR__ . "/paypal.php";
require_once __DIR__ . "/thumbnail-size.php";
