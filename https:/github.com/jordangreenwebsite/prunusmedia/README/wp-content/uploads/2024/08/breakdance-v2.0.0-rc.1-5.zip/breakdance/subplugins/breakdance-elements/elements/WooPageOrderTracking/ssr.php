<?php
/**
 * @var array $propertiesData
 */

echo do_shortcode('[woocommerce_order_tracking no-hijack]');

