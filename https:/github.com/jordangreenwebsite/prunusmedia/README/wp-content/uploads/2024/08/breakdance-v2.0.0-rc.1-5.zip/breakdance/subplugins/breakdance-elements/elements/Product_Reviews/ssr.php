<?php
/**
 * @var array $propertiesData
 */

global $product;
$product = wc_get_product();

comments_template();

?>