<?php
/**
 * @var array $propertiesData
 */

echo do_shortcode($propertiesData['content']['shortcode']['full_shortcode'] ?? '');
