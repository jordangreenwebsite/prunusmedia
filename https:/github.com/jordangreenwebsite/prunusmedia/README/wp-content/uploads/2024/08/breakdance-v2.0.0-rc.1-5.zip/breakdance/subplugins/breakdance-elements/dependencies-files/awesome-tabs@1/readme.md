This is a Soflyy package: https://github.com/soflyy/awesome-tabs
