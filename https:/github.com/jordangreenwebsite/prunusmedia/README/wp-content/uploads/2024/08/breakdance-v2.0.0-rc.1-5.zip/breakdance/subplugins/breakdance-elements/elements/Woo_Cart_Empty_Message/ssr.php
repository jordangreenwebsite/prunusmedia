<?php

\Breakdance\WooCommerce\CartBuilder\emptyMessage();
